# GMAIL SSMTP MAIL SERVER INSTALLATION SHELL SCRIPT

   **ssmtp installtion script for ubunut versions.**
   
   * Download the script.
  
  * change the file permission with 777
   
    ` ` ` sudo chmod 777 ssmtp.sh `
   
   * Run the script with sudo.
       
      ` ` ` sudo ./ssmtp.sh ` ` ` 

   * While installing it asks mail configuration select intrnet site and mail name select default name or provide mail name.

     **For installation demo video for installation use the below link:**

        [DEMO VIDEO SSMTP MAIL SERVER INSTALLATION SHELL SCRIPT](https://youtu.be/f28VamgFKq8)

## Note:

   To send mail through gamil ssmtp need to change the settings in gmail.There are two ways either need to follow anyone.
         
         * By Less Secure Apps
         * By Two Step Verification Apps password

 **If you are following "Less Secure Apps" provide your gmail id and gamil id password while installation.**
                                       
                                       or

**If you are following "Two Step Verification Apps Password" Provide gmail id and Generated App Password while installation. Detailed instructions added below.**

### Less Secure Apps :

   In Gmail select Account settings
     
     * Select security (https://myaccount.google.com/security)
     * Turn on the Less secure app access

### Two Step Verification Apps Password :
   
   In Gmail select Account settings
     
     * Select security (https://myaccount.google.com/security)
 
   In "Signing in to Google" row:
    
     * Turn On the  2-Step Verification.


   After turning on in same https://myaccount.google.com/security page.

     * select App Password.
     * App Password Window will open in which generate a password for apps.
     * Select the app and device.
     * App as Mail and device as your custom name
     * password will be genrated with 16 letters like ygjrmktwbkmawklx.
     * Copy and keep it for a while.

   **While gmail ssmtp installation Povide the gamil id and provide the Generated app password(ygjrmktwbkmawklx) instead of normal gmail password.**
